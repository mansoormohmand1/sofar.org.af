import { hydrateStart, StartClient } from "@tanstack/react-start-client";
import { getRouter } from "./router";

const router = await hydrateStart(() => getRouter());

export default function ClientApp() {
  return <StartClient router={router} />;
}
